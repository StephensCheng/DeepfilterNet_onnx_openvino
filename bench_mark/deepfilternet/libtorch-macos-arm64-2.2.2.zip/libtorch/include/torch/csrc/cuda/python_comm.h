#pragma once

namespace torch::cuda::python {

void initCommMethods(PyObject* module);

} // namespace torch::cuda::python
