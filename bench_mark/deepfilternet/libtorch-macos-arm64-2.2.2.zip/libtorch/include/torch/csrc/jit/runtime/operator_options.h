#pragma once

#include <ATen/core/dispatch/OperatorOptions.h>

namespace torch::jit {

using AliasAnalysisKind = c10::AliasAnalysisKind;

} // namespace torch::jit
